// CivicConnect AI - Frontend logic (minimal vanilla JS)

const API_BASE_URL = "http://127.0.0.1:8000";

function getStoredAuth() {
  const token = localStorage.getItem("cc_token");
  const userJson = localStorage.getItem("cc_user");
  return {
    token,
    user: userJson ? JSON.parse(userJson) : null,
  };
}

function saveAuth(token, user) {
  localStorage.setItem("cc_token", token);
  localStorage.setItem("cc_user", JSON.stringify(user));
}

function clearAuth() {
  localStorage.removeItem("cc_token");
  localStorage.removeItem("cc_user");
}

async function authFetch(path, options = {}) {
  const { token } = getStoredAuth();
  const url = `${API_BASE_URL}${path}`;
  const finalOptions = { ...options };
  finalOptions.headers = finalOptions.headers || {};
  if (token) {
    finalOptions.headers["Authorization"] = `Bearer ${token}`;
  }
  return fetch(url, finalOptions);
}

function requireRole(allowedRoles) {
  const { token, user } = getStoredAuth();
  if (!token || !user || !allowedRoles.includes(user.role)) {
    window.location.href = "login.html";
  }
  return { token, user };
}

function bindLogout() {
  const btn = document.getElementById("logoutBtn");
  if (!btn) return;
  btn.addEventListener("click", () => {
    clearAuth();
    window.location.href = "index.html";
  });
}

// --- Page initializers ---

async function initLoginPage() {
  const form = document.getElementById("loginForm");
  const errorBox = document.getElementById("loginError");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.textContent = "";

    const formData = new FormData(form);
    const payload = {
      email: formData.get("email"),
      password: formData.get("password"),
    };

    try {
      const res = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        errorBox.textContent = data.detail || "Login failed. Please check your credentials.";
        return;
      }
      const data = await res.json();
      saveAuth(data.access_token, data.user);

      const role = data.user.role;
      if (role === "citizen") {
        window.location.href = "dashboard.html";
      } else if (role === "department") {
        window.location.href = "department.html";
      } else if (role === "admin") {
        window.location.href = "admin.html";
      } else {
        window.location.href = "index.html";
      }
    } catch (err) {
      errorBox.textContent = "Network error. Please try again.";
    }
  });
}

async function initRegisterPage() {
  const form = document.getElementById("registerForm");
  const errorBox = document.getElementById("registerError");
  const successBox = document.getElementById("registerSuccess");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.textContent = "";
    successBox.textContent = "";

    const formData = new FormData(form);
    const password = formData.get("password");
    const confirm = formData.get("confirmPassword");
    if (password !== confirm) {
      errorBox.textContent = "Passwords do not match.";
      return;
    }

    const payload = {
      name: formData.get("name"),
      email: formData.get("email"),
      password: password,
    };

    try {
      const res = await fetch(`${API_BASE_URL}/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        errorBox.textContent = data.detail || "Registration failed.";
        return;
      }
      successBox.textContent = "Registration successful. You can now log in.";
      form.reset();
    } catch (err) {
      errorBox.textContent = "Network error. Please try again.";
    }
  });
}

async function initCitizenDashboard() {
  const { user } = requireRole(["citizen"]);
  bindLogout();

  const welcome = document.getElementById("citizenWelcome");
  if (welcome && user) {
    welcome.textContent = `Welcome, ${user.name}`;
  }

  await loadCitizenComplaints();
}

async function loadCitizenComplaints() {
  const list = document.getElementById("citizenComplaints");
  const empty = document.getElementById("citizenComplaintsEmpty");
  if (!list) return;
  list.innerHTML = "";

  try {
    const res = await authFetch("/complaints/my");
    if (!res.ok) {
      throw new Error("Failed to load complaints");
    }
    const complaints = await res.json();
    if (!complaints.length) {
      if (empty) empty.style.display = "block";
      return;
    }
    if (empty) empty.style.display = "none";

    complaints.forEach((c) => {
      const card = document.createElement("div");
      card.className = "cc-complaint-card";

      const created = c.createdAt ? new Date(c.createdAt).toLocaleString() : "";
      const statusClass =
        c.status === "Resolved"
          ? "resolved"
          : c.status === "In Progress"
          ? "in-progress"
          : "";
      const priorityClass = c.priority ? c.priority.toLowerCase() : "";

      card.innerHTML = `
        <div class="cc-complaint-header">
          <div>
            <div class="cc-complaint-title">${c.title}</div>
            <div class="cc-complaint-meta">
              <span>${created}</span>
              <span>Category: <strong>${c.category}</strong></span>
              <span>Department: <strong>${c.departmentAssigned}</strong></span>
            </div>
          </div>
          <div class="cc-complaint-meta cc-text-right">
            <span class="cc-badge cc-badge-status ${statusClass}">${c.status}</span>
            <span class="cc-badge cc-badge-priority ${priorityClass}">${c.priority}</span>
          </div>
        </div>
        <div class="cc-complaint-body">
          ${c.description}
        </div>
        <div class="cc-complaint-footer">
          <div class="cc-chips-row">
            ${
              c.imagePath
                ? `<span class="cc-chip">Image attached</span>`
                : ""
            }
            ${
              c.audioPath
                ? `<span class="cc-chip">Audio attached</span>`
                : ""
            }
          </div>
          <div class="cc-muted">
            ${
              c.responseNote
                ? `<strong>Response:</strong> ${c.responseNote}`
                : "Awaiting department response"
            }
          </div>
        </div>
      `;
      list.appendChild(card);
    });
  } catch (err) {
    if (empty) {
      empty.textContent = "Could not load complaints. Please refresh.";
      empty.style.display = "block";
    }
  }
}

async function initReportPage() {
  requireRole(["citizen"]);
  bindLogout();

  const form = document.getElementById("reportForm");
  const errorBox = document.getElementById("reportError");
  const successBox = document.getElementById("reportSuccess");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    errorBox.textContent = "";
    successBox.textContent = "";

    const formData = new FormData(form);

    try {
      const res = await authFetch("/complaints/", {
        method: "POST",
        body: formData,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        errorBox.textContent = data.detail || "Could not submit complaint.";
        return;
      }
      successBox.textContent = "Complaint submitted successfully.";
      form.reset();
      setTimeout(() => {
        window.location.href = "dashboard.html";
      }, 900);
    } catch (err) {
      errorBox.textContent = "Network error. Please try again.";
    }
  });
}

async function initDepartmentPage() {
  const { user } = requireRole(["department"]);
  bindLogout();

  const title = document.getElementById("departmentTitle");
  if (title && user) {
    title.textContent = user.departmentName || "Department Dashboard";
  }

  await loadDepartmentComplaints();
}

async function loadDepartmentComplaints() {
  const container = document.getElementById("departmentComplaints");
  const empty = document.getElementById("departmentComplaintsEmpty");
  if (!container) return;
  container.innerHTML = "";

  try {
    const res = await authFetch("/department/complaints");
    if (!res.ok) {
      throw new Error("Failed");
    }
    const complaints = await res.json();
    if (!complaints.length) {
      if (empty) empty.style.display = "block";
      return;
    }
    if (empty) empty.style.display = "none";

    complaints.forEach((c) => {
      const wrapper = document.createElement("div");
      wrapper.className = "cc-complaint-card";

      const statusClass =
        c.status === "Resolved"
          ? "resolved"
          : c.status === "In Progress"
          ? "in-progress"
          : "";
      const created = c.createdAt ? new Date(c.createdAt).toLocaleString() : "";

      wrapper.innerHTML = `
        <div class="cc-complaint-header">
          <div>
            <div class="cc-complaint-title">${c.title}</div>
            <div class="cc-complaint-meta">
              <span>${created}</span>
              <span>Citizen ID: <strong>${c.userId}</strong></span>
              <span>Priority: <strong>${c.priority}</strong></span>
            </div>
          </div>
          <div class="cc-complaint-meta cc-text-right">
            <span class="cc-badge cc-badge-status ${statusClass}">${c.status}</span>
          </div>
        </div>
        <div class="cc-complaint-body">${c.description}</div>
        <div class="cc-complaint-footer">
          <div class="cc-chips-row">
            ${
              c.imagePath
                ? `<span class="cc-chip">Image attached</span>`
                : ""
            }
            ${
              c.audioPath
                ? `<span class="cc-chip">Audio attached</span>`
                : ""
            }
          </div>
        </div>
        <div class="cc-field" style="margin-top:0.6rem;">
          <label class="cc-label">Update status</label>
          <select class="cc-select js-status-select">
            <option value="Pending" ${c.status === "Pending" ? "selected" : ""}>Pending</option>
            <option value="In Progress" ${c.status === "In Progress" ? "selected" : ""}>In Progress</option>
            <option value="Resolved" ${c.status === "Resolved" ? "selected" : ""}>Resolved</option>
          </select>
        </div>
        <div class="cc-field">
          <label class="cc-label">Response note</label>
          <textarea class="cc-textarea js-response-note" placeholder="Write a brief response to the citizen...">${
            c.responseNote || ""
          }</textarea>
        </div>
        <div class="cc-form-actions">
          <button class="cc-btn-primary js-update-btn" type="button">Save update</button>
        </div>
      `;

      const statusSelect = wrapper.querySelector(".js-status-select");
      const noteInput = wrapper.querySelector(".js-response-note");
      const updateBtn = wrapper.querySelector(".js-update-btn");

      updateBtn.addEventListener("click", async () => {
        updateBtn.disabled = true;
        updateBtn.textContent = "Saving...";
        try {
          const res = await authFetch(`/department/complaints/${c.id}`, {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              status: statusSelect.value,
              responseNote: noteInput.value,
            }),
          });
          if (!res.ok) {
            alert("Could not update complaint.");
          } else {
            await loadDepartmentComplaints();
          }
        } catch (err) {
          alert("Network error while updating.");
        } finally {
          updateBtn.disabled = false;
          updateBtn.textContent = "Save update";
        }
      });

      container.appendChild(wrapper);
    });
  } catch (err) {
    if (empty) {
      empty.textContent = "Could not load complaints. Please refresh.";
      empty.style.display = "block";
    }
  }
}

async function initAdminPage() {
  requireRole(["admin"]);
  bindLogout();
  await Promise.all([loadAdminAnalytics(), loadAdminComplaints(), loadAdminUsers()]);
}

async function loadAdminAnalytics() {
  const totalEl = document.getElementById("metricTotal");
  const pendingEl = document.getElementById("metricPending");
  const resolvedEl = document.getElementById("metricResolved");
  const highEl = document.getElementById("metricHigh");
  const chartCanvas = document.getElementById("complaintsChart");

  try {
    const res = await authFetch("/admin/analytics");
    if (!res.ok) throw new Error();
    const data = await res.json();

    if (totalEl) totalEl.textContent = data.total ?? 0;
    if (pendingEl) pendingEl.textContent = data.pending ?? 0;
    if (resolvedEl) resolvedEl.textContent = data.resolved ?? 0;
    if (highEl) highEl.textContent = data.highPriority ?? 0;

    if (chartCanvas && window.Chart) {
      const ctx = chartCanvas.getContext("2d");
      // eslint-disable-next-line no-unused-vars
      new Chart(ctx, {
        type: "doughnut",
        data: {
          labels: ["Pending", "Resolved", "High priority"],
          datasets: [
            {
              data: [data.pending || 0, data.resolved || 0, data.highPriority || 0],
              backgroundColor: ["#3b82f6", "#22c55e", "#ef4444"],
            },
          ],
        },
        options: {
          plugins: {
            legend: { position: "bottom" },
          },
        },
      });
    }
  } catch (err) {
    if (totalEl) totalEl.textContent = "-";
  }
}

async function loadAdminComplaints() {
  const container = document.getElementById("adminComplaints");
  if (!container) return;
  container.innerHTML = "";

  try {
    const res = await authFetch("/admin/complaints");
    if (!res.ok) throw new Error();
    const complaints = await res.json();

    complaints.forEach((c) => {
      const row = document.createElement("tr");
      const created = c.createdAt ? new Date(c.createdAt).toLocaleString() : "";
      row.innerHTML = `
        <td>${c.title}</td>
        <td>${c.category}</td>
        <td>${c.departmentAssigned}</td>
        <td>${c.priority}</td>
        <td>${c.status}</td>
        <td>${created}</td>
        <td>
          <button class="cc-btn-ghost js-delete-complaint" data-id="${c.id}">Delete</button>
        </td>
      `;
      container.appendChild(row);
    });

    container.querySelectorAll(".js-delete-complaint").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        if (!id) return;
        if (!confirm("Delete this complaint?")) return;
        btn.disabled = true;
        try {
          const resDel = await authFetch(`/admin/complaints/${id}`, {
            method: "DELETE",
          });
          if (!resDel.ok) {
            alert("Could not delete complaint.");
          } else {
            await loadAdminComplaints();
            await loadAdminAnalytics();
          }
        } catch (err) {
          alert("Network error while deleting.");
        } finally {
          btn.disabled = false;
        }
      });
    });
  } catch (err) {
    const row = document.createElement("tr");
    row.innerHTML = `<td colspan="7">Could not load complaints.</td>`;
    container.appendChild(row);
  }
}

async function loadAdminUsers() {
  const container = document.getElementById("adminUsers");
  const form = document.getElementById("departmentUserForm");
  const formMsg = document.getElementById("departmentUserMessage");
  if (!container) return;
  container.innerHTML = "";

  try {
    const res = await authFetch("/admin/users");
    if (!res.ok) throw new Error();
    const users = await res.json();

    users.forEach((u) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${u.name}</td>
        <td>${u.email}</td>
        <td><span class="cc-badge cc-badge-role ${u.role}">${u.role}</span></td>
        <td>${u.departmentName || "-"}</td>
      `;
      container.appendChild(row);
    });
  } catch (err) {
    const row = document.createElement("tr");
    row.innerHTML = `<td colspan="4">Could not load users.</td>`;
    container.appendChild(row);
  }

  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (formMsg) formMsg.textContent = "";

      const formData = new FormData(form);
      const payload = {
        name: formData.get("name"),
        email: formData.get("email"),
        password: formData.get("password"),
        departmentName: formData.get("departmentName"),
      };

      try {
        const res = await authFetch("/admin/departments", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          if (formMsg) formMsg.textContent = data.detail || "Could not create department user.";
        } else {
          if (formMsg) formMsg.textContent = "Department user created.";
          form.reset();
          await loadAdminUsers();
        }
      } catch (err) {
        if (formMsg) formMsg.textContent = "Network error while creating user.";
      }
    });
  }
}

// Router based on data-page attribute

document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;

  switch (page) {
    case "login":
      initLoginPage();
      break;
    case "register":
      initRegisterPage();
      break;
    case "citizen-dashboard":
      initCitizenDashboard();
      break;
    case "report":
      initReportPage();
      break;
    case "department":
      initDepartmentPage();
      break;
    case "admin":
      initAdminPage();
      break;
    default:
      // Landing / index: nothing special
      bindLogout();
      break;
  }
});

