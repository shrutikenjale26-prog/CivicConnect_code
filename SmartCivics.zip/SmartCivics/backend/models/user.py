"""
User models and helpers.
"""

from typing import Any, Dict, Optional

from pydantic import BaseModel, EmailStr, Field

from database import db
from middleware.auth import hash_password


class UserBase(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr


class UserCreate(UserBase):
    password: str = Field(..., min_length=6, max_length=100)


class UserOut(UserBase):
    id: str
    role: str
    departmentName: Optional[str] = None

    class Config:
        orm_mode = True


async def get_user_by_email(email: str) -> Optional[Dict[str, Any]]:
    if db is None:
        return None
    return await db["users"].find_one({"email": email})


async def create_citizen_user(user_in: UserCreate) -> Dict[str, Any]:
    """
    Create a new citizen user.
    """
    if db is None:
        raise RuntimeError("Database not initialized")

    existing = await get_user_by_email(user_in.email)
    if existing:
        raise ValueError("User already exists")

    user_doc = {
        "_id": user_in.email,  # use email as primary ID for simplicity
        "name": user_in.name,
        "email": user_in.email,
        "password": hash_password(user_in.password),
        "role": "citizen",
        "departmentName": None,
    }
    await db["users"].insert_one(user_doc)
    return user_doc


async def init_default_users() -> None:
    """
    Seed the database with a default admin and sample department users.
    """
    if db is None:
        return

    users_collection = db["users"]

    # Default admin
    admin_email = "admin@civicconnect.com"
    admin = await users_collection.find_one({"email": admin_email})
    if not admin:
        admin_doc = {
            "_id": admin_email,
            "name": "System Admin",
            "email": admin_email,
            "password": hash_password("admin123"),
            "role": "admin",
            "departmentName": None,
        }
        await users_collection.insert_one(admin_doc)

    # Sample department users
    departments = [
        ("roads@civicconnect.com", "Roads Department", "Roads Manager"),
        ("water@civicconnect.com", "Water Department", "Water Manager"),
        ("sanitation@civicconnect.com", "Sanitation Department", "Sanitation Manager"),
        ("electrical@civicconnect.com", "Electrical Department", "Electrical Manager"),
    ]

    for email, dept_name, name in departments:
        existing = await users_collection.find_one({"email": email})
        if existing:
            continue
        dept_doc = {
            "_id": email,
            "name": name,
            "email": email,
            "password": hash_password("dept123"),
            "role": "department",
            "departmentName": dept_name,
        }
        await users_collection.insert_one(dept_doc)

