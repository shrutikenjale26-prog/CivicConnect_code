"""
Models package for CivicConnect AI backend.
"""

