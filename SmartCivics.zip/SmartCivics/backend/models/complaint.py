"""
Complaint models and helpers, including simple keyword-based AI classification.
"""

import os
import shutil
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4

from fastapi import HTTPException, UploadFile, status
from pydantic import BaseModel, Field

from database import db


class ComplaintCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=200)
    description: str = Field(..., min_length=10, max_length=4000)


class ComplaintOut(BaseModel):
    id: str
    userId: str
    title: str
    description: str
    category: str
    departmentAssigned: str
    priority: str
    status: str
    imagePath: Optional[str] = None
    audioPath: Optional[str] = None
    responseNote: Optional[str] = None
    createdAt: datetime

    class Config:
        orm_mode = True


def classify_complaint(description: str) -> Tuple[str, str, str]:
    """
    Very simple keyword-based classification with:
    - category
    - priority
    - department name
    """
    text = description.lower()

    # Category detection
    if "pothole" in text or "road" in text:
        category = "Roads"
        department = "Roads Department"
    elif "water" in text or "leakage" in text:
        category = "Water"
        department = "Water Department"
    elif "garbage" in text or "trash" in text:
        category = "Sanitation"
        department = "Sanitation Department"
    elif "electricity" in text or "power" in text:
        category = "Electrical"
        department = "Electrical Department"
    else:
        category = "General"
        department = "General Administration"

    # Priority detection
    if "urgent" in text or "dangerous" in text:
        priority = "High"
    elif "delay" in text or "issue" in text:
        priority = "Medium"
    else:
        priority = "Low"

    return category, priority, department


def _save_upload_file(upload: UploadFile, subdir: str) -> Optional[str]:
    """
    Save an uploaded file to the local filesystem and return the relative path.
    """
    if upload is None:
        return None

    extension = os.path.splitext(upload.filename)[1]
    unique_name = f"{uuid4().hex}{extension}"
    base_dir = os.path.join("uploads", subdir)
    os.makedirs(base_dir, exist_ok=True)
    path = os.path.join(base_dir, unique_name)

    try:
        with open(path, "wb") as buffer:
            shutil.copyfileobj(upload.file, buffer)
    finally:
        upload.file.close()

    return path


async def create_complaint_for_user(
    user_id: str,
    description: str,
    title: str,
    image: Optional[UploadFile],
    audio: Optional[UploadFile],
) -> Dict[str, Any]:
    """
    Create a complaint document, run classification, and save optional files.
    """
    if db is None:
        raise RuntimeError("Database not initialized")

    category, priority, department = classify_complaint(description)

    image_path = _save_upload_file(image, "images") if image else None
    audio_path = _save_upload_file(audio, "audio") if audio else None

    complaint_doc = {
        # use UUID for complaint id
        "_id": str(uuid4()),
        "userId": user_id,
        "title": title,
        "description": description,
        "category": category,
        "departmentAssigned": department,
        "priority": priority,
        "status": "Pending",
        "imagePath": image_path,
        "audioPath": audio_path,
        "responseNote": None,
        "createdAt": datetime.utcnow(),
    }

    await db["complaints"].insert_one(complaint_doc)
    return complaint_doc


def serialize_complaint(doc: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a MongoDB complaint document to a JSON-serializable dict.
    """
    return {
        "id": str(doc.get("_id")),
        "userId": doc.get("userId"),
        "title": doc.get("title"),
        "description": doc.get("description"),
        "category": doc.get("category"),
        "departmentAssigned": doc.get("departmentAssigned"),
        "priority": doc.get("priority"),
        "status": doc.get("status"),
        "imagePath": doc.get("imagePath"),
        "audioPath": doc.get("audioPath"),
        "responseNote": doc.get("responseNote"),
        "createdAt": doc.get("createdAt"),
    }


async def find_complaints_by_user(user_id: str) -> List[Dict[str, Any]]:
    if db is None:
        raise RuntimeError("Database not initialized")
    cursor = db["complaints"].find({"userId": user_id}).sort("createdAt", -1)
    complaints: List[Dict[str, Any]] = []
    async for doc in cursor:
        complaints.append(serialize_complaint(doc))
    return complaints


async def find_complaints_by_department(department_name: str) -> List[Dict[str, Any]]:
    if db is None:
        raise RuntimeError("Database not initialized")
    cursor = db["complaints"].find({"departmentAssigned": department_name}).sort("createdAt", -1)
    complaints: List[Dict[str, Any]] = []
    async for doc in cursor:
        complaints.append(serialize_complaint(doc))
    return complaints


async def get_all_complaints() -> List[Dict[str, Any]]:
    if db is None:
        raise RuntimeError("Database not initialized")
    cursor = db["complaints"].find().sort("createdAt", -1)
    complaints: List[Dict[str, Any]] = []
    async for doc in cursor:
        complaints.append(serialize_complaint(doc))
    return complaints


async def update_complaint_status(
    complaint_id: str,
    status_value: str,
    response_note: Optional[str] = None,
) -> Dict[str, Any]:
    if db is None:
        raise RuntimeError("Database not initialized")

    valid_statuses = {"Pending", "In Progress", "Resolved"}
    if status_value not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid status value",
        )

    update_fields: Dict[str, Any] = {"status": status_value}
    if response_note is not None:
        update_fields["responseNote"] = response_note

    update_result = await db["complaints"].update_one({"_id": complaint_id}, {"$set": update_fields})
    if update_result.matched_count == 0:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Complaint not found",
        )
    updated = await db["complaints"].find_one({"_id": complaint_id})
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Complaint not found after update",
        )
    return serialize_complaint(updated)


async def delete_complaint(complaint_id: str) -> None:
    if db is None:
        raise RuntimeError("Database not initialized")
    result = await db["complaints"].delete_one({"_id": complaint_id})
    if result.deleted_count == 0:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Complaint not found",
        )

