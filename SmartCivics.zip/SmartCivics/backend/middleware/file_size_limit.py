"""
Simple middleware to restrict maximum upload size.
"""

from typing import Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response


class FileSizeLimitMiddleware(BaseHTTPMiddleware):
    """
    Reject requests whose Content-Length exceeds the configured max_upload_size.
    """

    def __init__(self, app, max_upload_size: int = 5 * 1024 * 1024) -> None:
        super().__init__(app)
        self.max_upload_size = max_upload_size

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        content_length = request.headers.get("content-length")
        if content_length is not None:
            try:
                size = int(content_length)
                if size > self.max_upload_size:
                    return Response(
                        content=f"File too large. Max size is {self.max_upload_size} bytes.",
                        status_code=413,
                    )
            except ValueError:
                # If we cannot parse content-length, fall through.
                pass
        return await call_next(request)

