"""
Entry point for CivicConnect AI – Smart City Civic Issue Reporting Platform.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import close_mongo_connection, connect_to_mongo
from middleware.file_size_limit import FileSizeLimitMiddleware
from models.user import init_default_users
from routes import admin, auth, complaints, department

app = FastAPI(
    title="CivicConnect AI – Smart City Civic Issue Reporting Platform",
    version="1.0.0",
)

# CORS for local frontend (file:// or http://localhost)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Restrict file upload size (5 MB)
app.add_middleware(FileSizeLimitMiddleware, max_upload_size=5 * 1024 * 1024)

# Routers
app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(complaints.router, prefix="/complaints", tags=["Complaints"])
app.include_router(department.router, prefix="/department", tags=["Department"])
app.include_router(admin.router, prefix="/admin", tags=["Admin"])


@app.on_event("startup")
async def on_startup() -> None:
    await connect_to_mongo()
    await init_default_users()


@app.on_event("shutdown")
async def on_shutdown() -> None:
    await close_mongo_connection()


@app.get("/health")
async def health_check() -> dict:
    """
    Basic health check endpoint.
    """
    return {"status": "ok"}

