"""
Database configuration for CivicConnect AI.

Uses Motor (async MongoDB driver) with a simple global client/database handle.
"""

from typing import Optional

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

MONGO_URL = "mongodb://localhost:27017"
DB_NAME = "civicconnect_ai"

client: Optional[AsyncIOMotorClient] = None
db: Optional[AsyncIOMotorDatabase] = None


async def connect_to_mongo() -> None:
    """
    Initialize MongoDB connection.
    """
    global client, db
    if client is None:
        client = AsyncIOMotorClient(MONGO_URL)
        db = client[DB_NAME]


async def close_mongo_connection() -> None:
    """
    Close MongoDB connection on shutdown.
    """
    global client
    if client is not None:
        client.close()
        client = None

