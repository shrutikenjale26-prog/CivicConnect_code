"""
Citizen complaint endpoints.
"""

from typing import Any, Dict, List

from fastapi import APIRouter, Depends, File, Form, UploadFile

from middleware.auth import role_required
from models.complaint import (
    ComplaintOut,
    create_complaint_for_user,
    find_complaints_by_user,
)

router = APIRouter()


@router.post("/", response_model=ComplaintOut)
async def submit_complaint(
    title: str = Form(...),
    description: str = Form(...),
    image: UploadFile | None = File(None),
    audio: UploadFile | None = File(None),
    current_user: Dict[str, Any] = Depends(role_required(["citizen"])),
):
    """
    Submit a new complaint with optional image and audio attachments.
    """
    complaint = await create_complaint_for_user(
        user_id=current_user["_id"],
        description=description,
        title=title,
        image=image,
        audio=audio,
    )
    return complaint


@router.get("/my", response_model=List[ComplaintOut])
async def list_my_complaints(
    current_user: Dict[str, Any] = Depends(role_required(["citizen"]))
):
    """
    Get all complaints created by the authenticated citizen.
    """
    complaints = await find_complaints_by_user(current_user["_id"])
    return complaints

