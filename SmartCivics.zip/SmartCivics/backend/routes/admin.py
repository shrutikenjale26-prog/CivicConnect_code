"""
Admin dashboard endpoints.
"""

from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field

from database import db
from middleware.auth import hash_password, role_required
from models.complaint import (
    ComplaintOut,
    delete_complaint,
    get_all_complaints,
)

router = APIRouter()


class DepartmentUserCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=100)
    departmentName: str = Field(..., min_length=2, max_length=200)


@router.get("/complaints", response_model=List[ComplaintOut])
async def list_all_complaints(
    current_user: Dict[str, Any] = Depends(role_required(["admin"]))
):
    """
    List all complaints in the system.
    """
    complaints = await get_all_complaints()
    return complaints


@router.delete("/complaints/{complaint_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_complaint(
    complaint_id: str,
    current_user: Dict[str, Any] = Depends(role_required(["admin"])),
):
    """
    Delete a complaint (for demo and cleanup).
    """
    await delete_complaint(complaint_id)
    return None


@router.get("/users", response_model=List[Dict[str, Any]])
async def list_users(
    current_user: Dict[str, Any] = Depends(role_required(["admin"]))
):
    """
    List all users (excluding password hashes).
    """
    if db is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database not initialized",
        )
    cursor = db["users"].find()
    users: List[Dict[str, Any]] = []
    async for doc in cursor:
        users.append(
            {
                "id": doc.get("_id"),
                "name": doc.get("name"),
                "email": doc.get("email"),
                "role": doc.get("role"),
                "departmentName": doc.get("departmentName"),
            }
        )
    return users


@router.post("/departments", response_model=Dict[str, Any], status_code=status.HTTP_201_CREATED)
async def create_department_user(
    payload: DepartmentUserCreate,
    current_user: Dict[str, Any] = Depends(role_required(["admin"])),
):
    """
    Create a new department user account.
    """
    if db is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database not initialized",
        )

    existing = await db["users"].find_one({"email": payload.email})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this email already exists",
        )

    user_doc = {
        "_id": payload.email,
        "name": payload.name,
        "email": payload.email,
        "password": hash_password(payload.password),
        "role": "department",
        "departmentName": payload.departmentName,
    }
    await db["users"].insert_one(user_doc)

    return {
        "id": user_doc["_id"],
        "name": user_doc["name"],
        "email": user_doc["email"],
        "role": user_doc["role"],
        "departmentName": user_doc["departmentName"],
    }


@router.get("/analytics", response_model=Dict[str, int])
async def analytics(
    current_user: Dict[str, Any] = Depends(role_required(["admin"]))
):
    """
    Simple analytics for admin dashboard.
    """
    if db is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database not initialized",
        )

    total = await db["complaints"].count_documents({})
    pending = await db["complaints"].count_documents({"status": "Pending"})
    resolved = await db["complaints"].count_documents({"status": "Resolved"})
    high_priority = await db["complaints"].count_documents({"priority": "High"})

    return {
        "total": total,
        "pending": pending,
        "resolved": resolved,
        "highPriority": high_priority,
    }

