"""
Department dashboard endpoints.
"""

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from middleware.auth import role_required
from models.complaint import (
    ComplaintOut,
    find_complaints_by_department,
    update_complaint_status,
)

router = APIRouter()


class StatusUpdate(BaseModel):
    status: str
    responseNote: Optional[str] = None


@router.get("/complaints", response_model=List[ComplaintOut])
async def get_department_complaints(
    current_user: Dict[str, Any] = Depends(role_required(["department"]))
):
    """
    List complaints assigned to the authenticated department user.
    """
    department_name = current_user.get("departmentName")
    complaints = await find_complaints_by_department(department_name)
    return complaints


@router.patch("/complaints/{complaint_id}", response_model=ComplaintOut)
async def update_department_complaint(
    complaint_id: str,
    payload: StatusUpdate,
    current_user: Dict[str, Any] = Depends(role_required(["department"])),
):
    """
    Update complaint status and optional response note.
    """
    updated = await update_complaint_status(
        complaint_id=complaint_id,
        status_value=payload.status,
        response_note=payload.responseNote,
    )
    return updated

