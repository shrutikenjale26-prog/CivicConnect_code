"""
Authentication routes: registration and login.
"""

from datetime import timedelta
from typing import Any, Dict

from fastapi import APIRouter, HTTPException, status
from fastapi import Depends
from pydantic import BaseModel, EmailStr

from database import db
from middleware.auth import (
    ACCESS_TOKEN_EXPIRE_MINUTES,
    create_access_token,
    verify_password,
)
from models.user import UserCreate, create_citizen_user, get_user_by_email

router = APIRouter()


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: Dict[str, Any]


@router.post("/register", response_model=Dict[str, Any], status_code=status.HTTP_201_CREATED)
async def register_user(payload: UserCreate):
    """
    Register a new citizen user.
    """
    try:
        user_doc = await create_citizen_user(payload)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User with this email already exists",
        )

    return {
        "id": user_doc["_id"],
        "name": user_doc["name"],
        "email": user_doc["email"],
        "role": user_doc["role"],
        "departmentName": user_doc.get("departmentName"),
    }


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest):
    """
    Authenticate a user and return a JWT access token.
    """
    if db is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Database not initialized",
        )

    user = await get_user_by_email(payload.email)
    if not user or not verify_password(payload.password, user["password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
        )

    token_data = {
        "sub": user["_id"],
        "role": user["role"],
        "departmentName": user.get("departmentName"),
    }
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    token = create_access_token(token_data, access_token_expires)

    user_payload = {
        "id": user["_id"],
        "name": user["name"],
        "email": user["email"],
        "role": user["role"],
        "departmentName": user.get("departmentName"),
    }

    return TokenResponse(access_token=token, user=user_payload)

